/* PERMITTED COMMANDS
   move(); turnLeft(); putLeaf(); removeLeaf();
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below
        turnRight();
        move();
        turnLeft();
        for(int i=0;i<9;i++)
        {
            if(i!=6)
            {
            move();
            }
            else 
            {
                turnLeft();
                move();
            }
        }
        removeLeaf();
        TurnAround();
for(int i=0;i<9;i++)
        {
            if(i!=3)
            {
            move();
            }
            else 
            {
                turnRight();
                move();
            }
        }
        turnLeft();
        move();
        putLeaf();
        TurnAround();
        move();
        move();
    }
    void TurnAround()
    {
        turnLeft();
        turnLeft();
    }
}