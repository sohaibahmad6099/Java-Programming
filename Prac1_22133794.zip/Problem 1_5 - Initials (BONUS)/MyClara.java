/* PERMITTED COMMANDS
   move(); turnLeft(); putLeaf(); removeLeaf();
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below
            LetterM();
            LetterA();
        }



        void LetterA()

        {
            turnLeft();
            move();
            move();
            turnLeft();
            for(int i=0;i<6;i++)
            {
                removeLeaf();
                move();
            }
            turnRight();
            for(int i=0;i<2;i++)
            {
                move();
                removeLeaf();
            }
            move();
            turnRight();
            for(int i=0;i<6;i++)
            {
                move();
                removeLeaf();
            }
            TurnAround();
            TriplleMove();
            turnLeft();
            for(int i=0;i<2;i++)
            {
                move();
                removeLeaf();
            }
        }



















        void LetterM()
        {
            turnRight();
        move();
        for(int i=0;i<7;i++)
        {
            removeLeaf();
            move();
        }
        TriplleMove();
        for(int i=0;i<2;i++)
        {
            move();
        turnLeft();
        move();
        removeLeaf();
        turnRight();
        }
        TurnAround();
for(int i=0;i<1;i++)
        {
            move();
        turnRight();
        move();
        removeLeaf();
        turnLeft();
        }
        turnRight();
        move();
        removeLeaf();
        turnRight();
        for(int i=0;i<6;i++)
        {
            move();
            removeLeaf();
        }
        }
        void TurnAround()
        {
            turnLeft();
            turnLeft();
        }
        void TriplleMove()
        {
            for(int i=0;i<3;i++)
            {
                move();
            }
        }
}