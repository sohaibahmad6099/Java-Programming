/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
     int age = 0;int height = 0;
    void run() {
        // TODO: Write your code below
        Cake();
        age = readInt("Enter the age of your Grandmother: ");
        height = age %10 ;
        age = age/10;
        if(height==0)
        {
            height = 1;
        }
        for(int i=0;i<(18-age)/4;i++)
        {
            move();
        }
        Candles();
    }
    // This prints the candles based on the age enterd 
        void Candles()
    {
        for(int i=0;i<height;i++)
        {
            for(int j=0;j<age;j++)
            {
                    putLeaf();
                    move();
                    if(j<age-1)
                    {
                    move();
                    }
                
            }
            if(i%2==0)
            {
                TurnLeft();
            }   
            else
            {
                TurnRight();
            }
        }
    }
    // this will print the base of the cake 
    void Cake()
    {
        for(int i= 0;i<4;i++)
        {
            for(int j =0;j<18;j++)
            {
              putLeaf();
              move();   
            }
            if(i%2==0)
            {
                TurnLeft();
            }   
            else
            {
                TurnRight();
            }
        }
    }
    // this method will make clara turn left and move a line up 
    void TurnLeft()
    {
        turnLeft();
        move();
        turnLeft();
        move();
    }
    // this method will make clara turn right and move a line up 
    void TurnRight()
    {
        turnRight();
        move();
        turnRight();
        move();
    }
}