/* PERMITTED COMMANDS 
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf(); mushroomFront();
   onLeaf(x, y); putLeaf(x,y); removeLeaf(x,y); for sensing, adding or removing a leaf at coordinate (x,y)
   onFire(x, y); putFire(x,y); removeFire(x,y); for sensing, adding or removing a leaf at coordinate (x,y)
   getX(); getY(); for obtaining the current coordinates of Clara
   JAVA
   if, while, for, do, &&, ||, !
   variables, arrays
*/
class MyClara extends Clara {
    
    
    // constants
    final int WORLD_HEIGHT = 30;
    final int WORLD_WIDTH = 40;

    int X= 0;
    int Y=0;
    
    int count = 0;
    int n =0 ;
    // variables
    int[][] currentWorldState;
    int[][] nextWorldState;
    /**
     * Place leaves at random and then apply the game of life rules
     */
    void run()
    {
        if(CountLeaf()>0)
        {
            count++;
        }
        if(count==0)
        {
          FillArray();
        }
        if(count==1 && CheckFire()==0)
        {
        PutLeafAroundClara();

        //obtain the currentWorldState array by checking for leaves in the world
        currentWorldState = worldToArray(); 
        count++;       
        }
        else if(CheckFire()>0)
        {
            
        PutLeafAroundClara();
        currentWorldState = worldToArray();
        // // play game of life if not running for the first time
        nextWorldState = applyGameOfLifeRules(currentWorldState);
        updateWorld(nextWorldState);
        currentWorldState = nextWorldState;
        }
        

    }
    int CountLeaf()
    {
        int num =0;
        for (int i = 0; i < WORLD_WIDTH; i++)
        {
            for (int k = 0; k < WORLD_HEIGHT; k++)
            {
                if ( onLeaf(i,k) )
                    {
                        num++;
                    } 
            }
        }
        return num; 
    }
    int CheckFire()
    {
        int num =0;
        for (int i = 0; i < WORLD_WIDTH; i++)
        {
            for (int k = 0; k < WORLD_HEIGHT; k++)
            {
                if ( onFire(i,k) )
                    {
                        num++;
                    } 
            }
        }
        return num;
    }
    void PutLeafAroundClara()
    {
        int[][] retVal = new int[WORLD_WIDTH][WORLD_HEIGHT];
        GetClaraPosition();
        if(onLeaf(X,Y))
        {
            removeLeaf(X,Y);
            putFire(X,Y);
        }
        //  Put Fire on East of clara
        if(onLeaf(X+1,Y)&&(X + 1 < retVal.length))
        {
            removeLeaf(X+1,Y);
            putFire(X+1,Y);
        }
        // Put Fire on north of clara
       
        if(( Y + 1 < retVal[0].length)&&onLeaf( X,Y+ 1 ))
        {
            removeLeaf(X, Y + 1 );
            putFire(X, Y + 1 );
        }
        // put Fire omn South of clara
         int val = retVal[0].length;
        if(( Y -1  <= retVal[0].length)&&onLeaf(X,Y-1))
        {
            removeLeaf(X,Y-1);
            putFire(X,Y-1);
        }
        // Put Fire on West of clara
        if(( X -1  <= retVal.length)&&onLeaf(X-1,Y))
        {
            removeLeaf(X-1,Y);
            putFire(X-1,Y);
        }
    }
    // ii This gets the position of clara and stores it into variables
    void GetClaraPosition()
    {
        X = getX();
        Y = getY();
    }
    // i This method populates the world with random leafs 
    void FillArray()
    {
        for (int i = 0; i < WORLD_WIDTH; i++)
        {
            for (int k = 0; k < WORLD_HEIGHT; k++)
            {
                if ( Math.random()<=0.80 )
                    putLeaf(i,k);    
                else                
                    continue; 
            }
        }
    }
    /**
     * Scan the world for leaves and put true as the value of the 
     * corresponding array element if a leaf is found
     */
    int[][] worldToArray()
    {
        int[][] retVal = new int[WORLD_WIDTH][WORLD_HEIGHT];

        for (int i = 0; i <  WORLD_WIDTH; i++)
        {
            for (int k = 0; k <WORLD_HEIGHT; k++)
            {
                if ( onLeaf(i, k) )
                {
                    // 1 represents Leaf
                    retVal[i][k] = 1;    
                }
                else if(onFire(i,k)) 
                {
                    // 2 represents Fire              
                    retVal[i][k] = 2;
                }
                else 
                {
                    // 0 represents empty space 
                    retVal[i][k] = 0;
                }
            }
        }

        return retVal;
    }


    /**
     * Go through the every element of inInitialArray and apply game of life rules to it
     * The results will be stored in the array that this method returns
     */
     // This will spread the fire around the world
    int[][] applyGameOfLifeRules(int[][] inInitialArray)
{
    // Create a new array to store the next state of the world
    int[][] resultingArray = new int[inInitialArray.length][inInitialArray[0].length];

    // Iterate through each cell in the current state
    for (int i = 0; i < inInitialArray.length; i++)
    {
        for (int k = 0; k < inInitialArray[i].length; k++)
        {
            // If the current cell is on fire (represented by 2)
            if (inInitialArray[i][k] == 2)
            {
                // Spread fire to the neighboring cells
                spreadFire(inInitialArray, i, k);
            }
        }
    }

    return resultingArray;
}



    void spreadFire(int[][] inInitialArray,int i,int k)
    {
        if(onFire(i,k))
        {
            removeFire(i,k);
            inInitialArray[i][k] = 0;
        }
        if(onLeaf(i+1,k)&&(i + 1 < inInitialArray.length))
        {
            removeFire(i,k);
            inInitialArray[i][k] = 0;
            removeLeaf(i+1,k);
            inInitialArray[i+1][k] = 0;
            putFire(i+1,k);
            inInitialArray[i+1][k]=2;
        }
        if(( Y + 1 < inInitialArray[0].length)&&onLeaf( i,k+ 1 ))
        {
            removeFire(i,k);
            inInitialArray[i][k] = 0;
            removeLeaf(i, k + 1 );
            inInitialArray[i][k+1] = 0;
            putFire(i, k + 1 );
            inInitialArray[i][k+1]=2;
        }
        if(( Y -1  > 0)&&(Y-1 <inInitialArray[0].length)&&onLeaf(i,k-1))
        {
            removeFire(i,k);
            inInitialArray[i][k] = 0;
            removeLeaf(i,k-1);
            inInitialArray[i][k-1] = 0;
            putFire(i,k-1);
            inInitialArray[i][k-1]=2;
        }
        if(( i -1  > 0)&&(i-1 < inInitialArray.length)&&onLeaf(i-1,k))
        {
            removeFire(i,k);
            inInitialArray[i][k] = 0;
            removeLeaf(i-1,k);
            inInitialArray[i-1][k] = 0;
            putFire(i-1,k);
            inInitialArray[i-1][k]=2;
        }
    }
    /**
     * Remove all the leaves in Clara's world
     */
    void cleanWorld()
    {
        for (int i = 0; i < WORLD_WIDTH; i++)
        {
            for (int k = 0; k < WORLD_HEIGHT; k++)
            {
                if ( onLeaf(i, k) )
                    removeLeaf(i, k);
                if(onFire(i,k))
                    removeFire(i,k);
            }
        }
    }



    /**
     * Receives an array as input and for evey element that is true in this array
     * puts a leaf in Clara's world at the corresponding coordinate.
     */
    void updateWorld(int[][] inArray)
    {
        cleanWorld();

        for (int i = 0; i < inArray.length; i++)
        {
            for (int k = 0; k < inArray[i].length; k++)
            {
                if (inArray[i][k] == 0)
                    continue;
                else if(inArray[i][k]==2)
                {
                    putFire(i,k);
                }
                else if(inArray[i][k]==1)
                {
                    putLeaf(i,k);
                }
            }
        }
    }

}