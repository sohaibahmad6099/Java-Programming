/* PERMITTED COMMANDS 
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront,
   addTree(x, y),
   JAVA
   if, while, for, do, &&, !, ||, variables, arrays
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' function you can write your program for Clara 
     */
    int[][] arr =  new int[11][10];
    void run() {
        FillArray();
        drawTriangle();
        ClimbTrees();
    }
    // This will climbs the tree that will printed and move upto leaf 
    void ClimbTrees()
    {
        int i = 0;
        while(!onLeaf())
        {
            if(treeFront())
            {
                turnLeft();
                move();
                turnRight();
                move();
                i++;
            }
        }
        if(onLeaf())
        {
            removeLeaf();
        }
         turnRight();
        turnRight();
        while(i>0)
        {
            move();
            turnLeft();
            move();
            turnRight();
            i--;
        }
    }
    // This will draw the the trees on the map
    void drawTriangle()
    {
        for(int i=0;i<arr.length;i++)
        {
            for(int j = 0;j<arr[i].length;j++)
            {
                if(arr[i][j]==1)
                {
                    addTree(i,j);
                }
            }
        }
    }
    // this will add the trees on the map 
    void FillArray()
    {
        
        for(int i=0;i<6;i++)
        {
            int j =9;
            for(int l =0;l<=i;l++)
            {
                arr[i][j]=1;
                j--;
            }
        }
        
        for(int i=6;i<=10;i++)
        {
            int j =9;
            for(int l =0;l<=(10-i);l++)
            {
                arr[i][j]=1;
                j--;
            }
        }
      }
}
