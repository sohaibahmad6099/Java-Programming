/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
     int height = 0 ;
     int width = 0;
    void run() {
        // TODO: Write your code below
        height = 13;
        width = 20;
        while(height>14||width>21)
        {

        height = readInt("Enter the height of the cake");
        width = readInt("Enter the width of the cake");
       
        
        }
         Cake();
    }
    // we are using this to print the cake 
    void Cake()
    {
        for(int i= 0;i<height;i++)
        {
            for(int j =0;j<width;j++)
            {
              putLeaf();
              move();   
            }
            if(i%2==0)
            {
                TurnLeft();
            }   
            else
            {
                TurnRight();
            }
        }
    }
    void TurnLeft()
    {
        turnLeft();
        move();
        turnLeft();
        move();
    }
    void TurnRight()
    {
        turnRight();
        move();
        turnRight();
        move();
    }
}