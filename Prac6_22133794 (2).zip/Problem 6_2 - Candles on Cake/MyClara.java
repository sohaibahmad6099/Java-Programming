/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
     int height = 12;
     int  width = 20;
    void run() {
        // TODO: Write your code below
        
        while(height>11||width>19)
        {
        height = readInt("Enter the height it should be smaller or equal to 10: ");
        width = readInt("Enter the width it should be smaller or equal to 18: ");
        }
        Cake();
        Candles();
    }
    void Candles()
    {
    //     for(int j=0;j<width/2;j++)
    // {   
    //         turnRight();
    //     for(int i=0;i<3;i++)
    //     {
    //         putLeaf();
    //         move();            
    //     }
    //     TurnRight();
    //     TurnRight();
    //     for(int i=0;i<3;i++)
    //     {
    //         move();            
    //     }
    //     TurnRight();
    //     move();move();
    // }
        for(int i=0;i<3;i++)
        {
            if(width%2==0)
            {
            for(int j=0;j<width-1;j++)
            {
                if(j%2==0)
                {
                    putLeaf();
                }
                move();
            }
            }
            else 
            {
                 for(int j=0;j<width;j++)
            {
                if(j%2==0)
                {
                    putLeaf();
                }
                move();
            }
            }
            if(height%2==0)
            {
            if(i%2==0)
            {
                TurnLeft();
            }   
            else
            {
                TurnRight();
            }

            }
            else 
            {
                if(i%2==0)
            {
                TurnRight();
            }   
            else
            {
                TurnLeft();
            }
            }
            
        }
    }
    void Cake()
    {
        for(int i= 0;i<height;i++)
        {
            for(int j =0;j<width;j++)
            {
              putLeaf();
              move();   
            }
            if(i%2==0)
            {
                TurnLeft();
            }   
            else
            {
                TurnRight();
            }
        }
    }
    void TurnLeft()
    {
        turnLeft();
        move();
        turnLeft();
        move();
    }
    void TurnRight()
    {
        turnRight();
        move();
        turnRight();
        move();
    }
}

