/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
       while(!mushroomFront())
       {
            if(!treeFront())
                move();
            if(!onLeaf())
            {
                putLeaf();
            }
            else if(treeFront()&&!treeLeft())
            {
                turnLeft();
            }
            else if(treeFront()&&!treeRight())
            {
                turnRight();
            }
            if(treeRight()&&treeLeft()&&treeFront())
            {
                TurnAround();
                move();
            }
            if(!treeLeft()&&!treeRight())
            {
                turnRight();
            }
       }
           
    }
    boolean leftMaze()
    {
        while((!treeLeft()&&!treeRight())&&!treeFront())
        {`
           if(!treeFront())
                move();
            if(!onLeaf())
            {
                putLeaf();
            }
            else if(treeFront()&&!treeLeft())
            {
                turnLeft();
            }
            else if(treeFront()&&!treeRight())
            {
                turnRight();
            }
            if(!treeLeft()&&!treeRight())
            {
                turnRight();
            }
        }
        if(mushroomFront())
        {
            return true;
        }
        TurnAround();
        while(onLeaf())
        {
        `   if(!treeFront())
                move();
            else if(treeFront()&&!treeLeft())
            {
                turnLeft();
            }
            else if(treeFront()&&!treeRight())
            {
                turnRight();
            }
            if(!treeLeft()&&!treeRight())
            {
                turnRight();
            }
        }
        return false;
    }
    
    void RightMaze()
    {
        while(true)
        {`
           if(!treeFront())
                move();
            if(!onLeaf())
            {
                putLeaf();
            }
            else if(treeFront()&&!treeLeft())
            {
                turnLeft();
            }
            else if(treeFront()&&!treeRight())
            {
                turnRight();
            }
            if(!treeLeft()&&!treeRight())
            {
                turnRight();
            }
            if(treeLeft()&&treeRight()&&treeFront())
            {
                break;
            }
        }
        TurnAround();
        while(onLeaf())
        {
        `   if(!treeFront())
                move();
            else if(treeFront()&&!treeLeft())
            {
                turnLeft();
            }
            else if(treeFront()&&!treeRight())
            {
                turnRight();
            }
            if(!treeLeft()&&!treeRight())
            {
                turnRight();
            }
        }

    }
    void TurnAround()
    {
        turnRight();
        turnRight();
    }
}