/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, else, &&, ||, !, while, for
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        while(!mushroomFront())
    {   
        if(SafeMove())
        {
            break;
        }
        LeafRemover();
        if(treeFront())
        {
            if(GoAround())
            {
                break;
            }
        }
        if(!treeRight())
        {
            if(RightTree())
            {
                break;
            }
        }
        if(mushroomFront())
        {
            break;
        }
    }
    }
    // Remove the leaf on the right side  
    boolean RightTree()
    {
        turnRight();
        if(!mushroomFront())
            {
                move();
            }

        LeafRemover();
        turnLeft();
        if(mushroomFront())
            {
                return true;
              }
        if(treeFront())
        {
            turnLeft();
            if(mushroomFront())
            {
                return true;
              }
              else 
              {
                  move();
              }
            turnRight();
        }
        return false;
    }
    // Moves up 
    boolean GoAround()
    {
        turnLeft();
        if(mushroomFront())
            {
                return true;
              }
        move();
        if(mushroomFront())
            {
                return true;
              }
        turnRight();
        if(mushroomFront())
            {
                return true;
              }
        return false;
    }
    // Only moves if there is not a tree at front
    boolean SafeMove()
    {
        if(!treeFront()&&!mushroomFront())
        {
            move();
        }
        if(mushroomFront())
            {
                return true;
              }
        return false;
    }
    // To remove leaf if there is a leaf 
    void LeafRemover()
    {
        if(onLeaf())
        {
            removeLeaf();
        }
    }
}