/**
 * MyClara is a subclass of Clara. Therefore, it inherits all methods of Clara: <p>
 * 
 * 
 * PERMITTED COMMANDS
 * Actions:     move(), turnLeft(), turnRight(), putLeaf(), removeLeaf()
 *              mushroomFront(), canPushMushroom(), setNumberOfMoves(),
 *              testLevelComplete(), setDirectionUp(), setDirectionDown(),
 *              setDirectionLeft(), setDirectionRight(), getKey()
 * Sensors:     onLeaf(), treeFront(), mushroomFront()
 * JAVA:        if, else, while, for, !, &&, ||
 */
class MyClara extends Clara
{
    /**
     * In the 'act()' method you can write your program for Clara
     */
    int moves = 0;
    int count = 0;
    public void act()
    {
        if(count==0)
        {
        Movement();

        setNumberOfMoves(moves);
        if (testLevelComplete() && count == 0)
        {
            levelComplete();
            count++;
        }
        }

    }
    public void Movement()
    {
        if (Keyboard.isKeyDown("left"))
        {
            setDirectionLeft();
            move();
        }
        else if (Keyboard.isKeyDown("right"))
        {
            setDirectionRight();
            SafeMove();
        }
        else if (Keyboard.isKeyDown("down"))
        {
            setDirectionDown();
            SafeMove();
        }
        else if (Keyboard.isKeyDown("up"))
        {
            setDirectionUp();
            SafeMove();
        }
    }
    void SafeMove()
    {
        if (!treeFront() && !mushroomFront())
        {
            moves++;
            move();
        }
        else if (mushroomFront() && canPushMushroom())
        {
            moves++;
            move();
        }
    }
    
    public void levelComplete()
    {
        showWarning("Level Complete!");
    }

}