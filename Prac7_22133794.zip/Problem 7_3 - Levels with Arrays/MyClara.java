/**
 * MyClara is a subclass of Clara. Therefore, it inherits all methods of Clara: <p>
 * 
 * 
 * PERMITTED COMMANDS
 * Actions:     move(), turnLeft(), turnRight(), putLeaf(), removeLeaf()
 *              mushroomFront(), canPushMushroom(), setNumberOfMoves(),
 *              testLevelComplete(), setDirectionUp(), setDirectionDown(),
 *              setDirectionLeft(), setDirectionRight(), getKey()
 * Sensors:     onLeaf(), treeFront(), mushroomFront(), loadLevel()
 * JAVA:        if, else, while, for, !, &&, ||
 */
class MyClara extends Clara 
{
    public char[][] level1 = {
		{'#', '#', '#', '#', ' ', ' ', ' ', ' ', ' ', ' '},
        {'#', ' ', '|', '#', ' ', ' ', ' ', ' ', ' ', ' '},
        {'#', ' ', ' ', '#', '#', '#', ' ', ' ', ' ', ' '},
        {'#', ' ', '@', ' ', ' ', '#', ' ', ' ', ' ', ' '},
        {'#', ' ', ' ', '$', ' ', '#', ' ', ' ', ' ', ' '},
        {'#', ' ', ' ', '#', '#', '#', ' ', ' ', ' ', ' '},
        {'#', '#', '#', '#', ' ', ' ', ' ', ' ', ' ', ' '},
    };
    
    public char[][] level2 = {
        {'#', '#', '#', '#', '#', ' ', ' ', ' ', ' '},
        {'#', '@', ' ', ' ', '#', ' ', ' ', ' ', ' '},
        {'#', ' ', '$', '$', '#', ' ', '#', '#', '#'},
        {'#', ' ', '$', ' ', '#', ' ', '#', '|', '#'},
        {'#', '#', '#', ' ', '#', '#', '#', '|', '#'},
        {' ', '#', '#', ' ', ' ', ' ', ' ', '|', '#'},
        {' ', '#', ' ', ' ', ' ', '#', ' ', ' ', '#'},
        {' ', '#', ' ', ' ', ' ', '#', '#', '#', '#'},
        {' ', '#', '#', '#', '#', '#', ' ', ' ', ' '},
    };
    
    public char[][] level3 = {
        {'#', '#', '#', '#', '#', '#', ' '},
        {'#', ' ', ' ', ' ', ' ', '#', ' '},
        {'#', ' ', '#', '@', ' ', '#', ' '},
        {'#', ' ', '$', '*', ' ', '#', ' '},
        {'#', ' ', '|', '*', ' ', '#', ' '},
        {'#', ' ', ' ', ' ', ' ', '#', ' '},
        {'#', '#', '#', '#', '#', '#', ' '},
    };
    
    /**
     * In the 'act()' method you can write your program for Clara
     */
    
    private static int currentLevel = 0; 
    int moves = 0;
    boolean State = false;
    private char[][][] levels = {level1,level2,level3}; 
    private void act() 
    {
         Movement();
        if(State==false)
        {
            State = true;
            loadLevel(levels[currentLevel]);
        }
        if(currentLevel<levels.length)
        {

        Movement();
        setNumberOfMoves(moves);
        
        if(testLevelComplete()) 
        {
            levelComplete(); 
        }
        }
    }
   public void Movement()
    {
        if (Keyboard.isKeyDown("left"))
        {
            setDirectionLeft();
            SafeMove();
        }
        else if (Keyboard.isKeyDown("right"))
        {
            setDirectionRight();
            SafeMove();
        }
        else if (Keyboard.isKeyDown("down"))
        {
            setDirectionDown();
            SafeMove();
        }
        else if (Keyboard.isKeyDown("up"))
        {
            setDirectionUp();
            SafeMove();
        }
        
    }
        void SafeMove() 
    {
        // Move Clara only if there's no obstacle
        if (!treeFront() && !mushroomFront() ) 
        {
            moves++;
            move();
        } 
        // Push mushroom only if it can be pushed
        else if (mushroomFront() && canPushMushroom()) 
        {
            moves++;
            move(); 
        }
    }
    
       public void levelComplete() 
    {
        showWarning("Level "+ (currentLevel + 1) +" Complete!");

        currentLevel++; // Move to the next level

        if (currentLevel <levels.length) 
        {
            loadLevel(levels[currentLevel]); // Load the next level
        } 
        else 
        {
            showWarning("All Levels Completed!");
            currentLevel = 0; // Reset to the first level
            loadLevel(levels[currentLevel]);
        }
        
        // Reset the number of moves for the new level
        moves = 0;
    } 
}

