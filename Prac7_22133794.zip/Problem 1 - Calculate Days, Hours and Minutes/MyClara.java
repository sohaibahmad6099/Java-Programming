/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below
        int min=0,sec=0 ,hour = 0,days = 0 , time = 0;
        time = readInt("Enter your time in seconds ");
        
            min = time / 60;
            sec = time % 60;
            time = time/60;
            if(min > 59)
            {
                hour = min / 60 ;
                min = min%60;
            }
            if(hour>23)
            {
                days = hour / 24;
                hour = hour % 24;
            }
        
        System.out.println("Number of Days: "+ days);
        System.out.println("\n");
        System.out.println("Number of Hours: "+ hour);
        System.out.println("\n");
        System.out.println("Number of Minutes: "+ min);
        System.out.println("\n");
        System.out.println("Number of Seconds: "+ sec);
    }
}