/* PERMITTED COMMANDS 
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront,
   addTree(x, y),
   JAVA
   if, while, for, do, &&, !, ||, variables, arrays
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' function you can write your program for Clara 
     */
//     int[][] arr = {
//     {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},  // Row 0 (Empty)
//     {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},  // Row 1 (Empty)
//     {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},  // Row 2 (Empty)
//     {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},  // Row 3 (Empty)
//     {0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0},  // Row 5
//     {0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0},  // Row 6
//     {0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0},  // Row 7
//     {0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0},  // Row 9
//     {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},  // Row 8
//     {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}  // Row 11 (Widest row)
// };
    
    int[][] arr =  new int[11][10];
    void run() {
        FillArray();
        drawTriangle();
        ClimbTrees();
    }
    void ClimbTrees()
    {
        int i = 0;
        while(!onLeaf())
        {
            if(treeFront())
            {
                turnLeft();
                move();
                turnRight();
                move();
                i++;
            }
        }
        if(onLeaf())
        {
            removeLeaf();
        }
         turnRight();
        turnRight();
        while(i>0)
        {
            move();
            turnLeft();
            move();
            turnRight();
            i--;
        }
    }
    void drawTriangle()
    {
        for(int i=0;i<arr.length;i++)
        {
            for(int j = 0;j<arr[i].length;j++)
            {
                if(arr[i][j]==1)
                {
                    addTree(i,j);
                }
            }
        }
    }
    void FillArray()
    {
        
        for(int i=0;i<6;i++)
        {
            int j =9;
            for(int l =0;l<=i;l++)
            {
                arr[i][j]=1;
                j--;
            }
        }
        
        for(int i=6;i<=10;i++)
        {
            int j =9;
            for(int l =0;l<=(10-i);l++)
            {
                arr[i][j]=1;
                j--;
            }
        }
      }
}
