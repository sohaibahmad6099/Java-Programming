/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, else, &&, ||, !, while, for
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        while(!mushroomFront())
        {
            RemoveLeaf();
            if(!treeFront())
            {
                move();
            }
            RemoveLeaf();
            if(treeFront())
            {
                turnLeft();
                move();
                turnRight();
                move();
                while(treeRight())
                {
                    move();
                }
                turnRight();
                move();
                turnLeft();
            }
        }
        RemoveLeaf();
    }
    void RemoveLeaf()
    {
        if(onLeaf())
        {
            removeLeaf();
        }
    }
}