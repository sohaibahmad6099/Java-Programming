/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
       while(!mushroomFront())
       {
            if(!onLeaf())
            {
                putLeaf();
            }
            if(!treeFront())
            {
            move();
            }

            if(treeFront()&&!treeRight())
            {
                turnRight();
            }
            if(!treeLeft()&&treeFront()||(!treeLeft()&&!treeRight()&&!treeFront()))
            {
                turnLeft();
            }
            
            if(treeLeft()&&treeRight()&&treeFront())
            {
                turnRight();
                turnRight();
            }
       }
       putLeaf();
           
    }
}