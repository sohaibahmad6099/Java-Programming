/* PERMITTED COMMANDS
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf();
   JAVA
   if, else, for, while, do, !, ||, && 
   variables
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below
        int steps = 0, leaves = 0;
        // Keeps on moving until it reaches the end 
        while (!treeLeft() || !treeRight() || !treeFront()) {
            if (onLeaf()) {
                removeLeaf();
                leaves++;
            }
            if (treeLeft() && treeFront()) {
                turnRight();
            } 
            else if (!treeFront()) {
                move();
                steps++;
            }
        }
        // Will remove the leave when on the final leave 
        if (onLeaf()) {
                removeLeaf();
                leaves++;
            }
        System.out.println(leaves + " leaves, " + steps + " steps"); // Display the number of leaves
    }
}