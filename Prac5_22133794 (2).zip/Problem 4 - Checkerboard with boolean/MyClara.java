/* PERMITTED COMMANDS
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf();
   JAVA
   if, else, for, while, do, !, ||, && 
   variables
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below
        boolean tree = false;
        while((!treeLeft()||!treeRight())&&!treeFront())
        {
            PlaceLeaf();
                // Will turn based on the value of tree 
                if(tree==true)
                {
                    Turnright();
                    tree = false;
                }
                else if(tree==false)
                {
                    Turnleft();
                    tree = true;
                }
            
        }

    }
    void PlaceLeaf() // places leaf on every line
    {
        while(!treeFront()) 
            {
                putLeaf();
                SafeMove();
                SafeMove();
            }
    }
    void Turnleft() // makes clara turn left and move to the next line 
    {
        if(treeFront()&&!treeLeft())
        {
            turnLeft();
            SafeMove();
            turnLeft();
        }
    }
    
    void Turnright() // makes clara turn right and move to the next line 
    {
        if(treeFront()&&!treeRight())
        {
            turnRight();
            SafeMove();
            turnRight();
        }
    }
    void SafeMove() // Checkes if there is not a tree a front and than move 
    {
        if(!treeFront())
            move();
     
    }
}