/* PERMITTED COMMANDS
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf();
   JAVA
   if, else, for, while, do, !, ||, && 
   variables
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
        int length = 0; int width = 0; int tunnel = 0;
        int lengthSecondWorld = 0;
        int lengthAfterMushroom = 0; int WidthAfterMushroom = 0;
        int CountSteps = 0;
        boolean Mushroom = false;
    void run() {
        // TODO: Write your code below
        LenghtWidth();
        FindMushroom();
        FindClaraPositionAfterFindingMushroom();
        TakeMushroomToTunnel();
        FindLengthofSecondWorld();
        PlaceMushroomonLeaf();
    }
    // This will move the mushroom on the leaf
    void PlaceMushroomonLeaf()
    {
        for(int i=0;i<width-1;i++)
        {
            move();
        }
    }
    // This will find the length of second World and take clara against the wall
    void FindLengthofSecondWorld()
    {
        turnRight();
        while(!treeFront())
        {
            move();
            lengthSecondWorld++;
        }
        turnAround();
        for(int i =0;i<lengthSecondWorld;i++)
        {
            move();
        }
        move();
        turnRight();
        move();
        turnRight();

        for(int i=0;i<lengthSecondWorld;i++)
        {
            move();
        }
        turnRight();
        move();
        turnLeft();
        move();
        turnLeft();
    }
    // This code will take clara to the tunnel and pass it through the tunnel
    void TakeMushroomToTunnel()
    {
        for(int i=0;i<(width-WidthAfterMushroom)-1;i++)
        {
            move();
        }
        turnLeft();
        move();
        turnRight();
        move();
        turnRight();
        
        for(int i=0;i<(tunnel-lengthAfterMushroom);i++)
        {
            move();
        }
        turnRight();
        move();
        turnLeft();
        move();
        turnLeft();
        for(int i=0;i<6;i++)
        {
            move();
        }
    }
    // This will give us the location of clara after findinng the mushroom 
    void FindClaraPositionAfterFindingMushroom()
    {
        turnAround();
        while(!treeFront())
        {
            move();
            WidthAfterMushroom++;
        }
        turnRight();
        while(!treeFront())
        {
            move();
            lengthAfterMushroom++;
        }
        turnAround();
        for(int i =0; i<lengthAfterMushroom;i++)
        {
            move();
        }
        turnLeft();
        for(int i =0;i<WidthAfterMushroom;i++)
        {
            move();
        }
    }
    // Finds the mushroom and stops the code
    void FindMushroom()
    {
        while(!mushroomFront())
        {
            if(Mushroom==false)
            {
                CountSteps = 0;
                MoveUp();
            }
            if(Mushroom==false)
            {
                CountSteps = 0;
                MoveDown();
            }
        }
    }
    // This piece oof code is used to move Upwards and reposition to go down clara until it finds mushroom 
    void MoveUp()
    {
        while(!treeFront()&&!mushroomFront())
        {
            move();
            CountSteps ++;
        }
        
        if(mushroomFront())
        {
            turnLeft();
            move();
            turnRight();
            move();
            turnRight();
            Mushroom = true;
        }
        else
        {
        turnLeft();
        move();
        turnLeft();
        }
    }
    // This piece oof code is used to move Upwards and reposition to go up clara until it finds mushroom 
    void MoveDown()
    {
        while(!treeFront()&&!mushroomFront())
        {
            move();
            CountSteps ++;
        }
        
        if(mushroomFront())
        {
            turnRight();
            move();
            turnLeft();
            move();
            turnLeft();
            Mushroom =true;
        }
        else
        {
        turnRight();
        move();
        turnRight();
        }
    }
    // We use this function or method to turn around 
    void turnAround()
    {
        turnRight();
        turnRight();
    }
    
    // We use this piece of code to find the location of the tunnel and determine the length and width of the tunnel
    void LenghtWidth() 
    {
        while(!treeFront())
        {
            move();
            width++;
        }
        turnRight();
        while(treeLeft())
        {
            move();
            tunnel++;
            length++;
        }
        while(!treeFront())
        {
            move();
            length++;
        }
        turnAround();
    }
}