/* PERMITTED COMMANDS
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf();
   JAVA
   if, else, for, while, do, !, ||, && 
   variables
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below
        int steps = 0, leaves = 0;

        while (!treeLeft() || !treeRight() || !treeFront()) {
            if (onLeaf()) {
                removeLeaf();
                leaves++;
            }
            if (treeLeft() && treeFront()) {
                turnRight();
            } 
            else if (!treeFront()) {
                move();
                steps++;
            }
        }
        if (onLeaf()) {
                removeLeaf();
                leaves++;
            }
        System.out.println(leaves + " leaves, " + steps + " steps");
    }
}