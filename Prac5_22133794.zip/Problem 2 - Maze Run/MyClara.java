/* PERMITTED COMMANDS
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf();
   JAVA
   if, else, for, while, do, !, ||, && 
   variables
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below

        boolean tree = false;

        while (!mushroomFront()) {
            if (onLeaf()) {
                removeLeaf();               
                tree = true; 
            } 
            while (!treeFront()&&!mushroomFront()) {
                    move();
            }
            if(tree==false&&!mushroomFront())
            {
                turnLeft();
            }
            else if(tree==true&&! mushroomFront())
            {
                turnRight();
                tree = false;
            }
        }
    }
}