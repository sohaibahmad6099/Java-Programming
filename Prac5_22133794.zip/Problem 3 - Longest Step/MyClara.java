/* PERMITTED COMMANDS
   move(); turnLeft(); turnRight(); treeLeft(); treeRight(); treeFront(); onLeaf(); putLeaf(); removeLeaf();
   JAVA
   if, else, for, while, do, !, ||, && 
   variables
*/
   
class MyClara extends Clara { 
    void run() {
        int step = 0, max = 0;

        while(!onLeaf()) {
            if (treeFront()) {
                turnLeft();
                move();
                turnRight();
                step = 0; // Reset step since Clara turns
            } else {
                move();
                step++;
            }

            if (step > max) {
                max = step; // Update max if current steps are greater
            }
        }
                removeLeaf();
        System.out.println("longest step = " + max);
    }
}
